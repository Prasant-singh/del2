import numpy as np
def iou(box1, box2):
    """
    box: [x1, y1, x2, y2]
    returns IOU between box1 and box2
    """
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])

    inter_area = max(0, x2 - x1) * max(0, y2 - y1)
    box1_area = (box1[2]-box1[0]) * (box1[3]-box1[1])
    box2_area = (box2[2]-box2[0]) * (box2[3]-box2[1])

    union_area = box1_area + box2_area - inter_area

    if union_area == 0:
        return 0
    return inter_area / union_area

class SimpleTracker:
    def __init__(self, iou_threshold=0.75):
        self.iou_threshold = iou_threshold
        self.next_id = 0
        self.tracks = {}  # id: bbox

    def update(self, detections):
        updated_tracks = {}
        used_detections = set()
        matched_ids = set()

        for track_id, track_bbox in self.tracks.items():
            best_iou = 0
            best_match = -1
            for i, det_bbox in enumerate(detections):
                if i in used_detections:
                    continue
                current_iou = iou(track_bbox, det_bbox)
                if current_iou > best_iou:
                    best_iou = current_iou
                    best_match = i

            if best_iou >= self.iou_threshold:
                updated_tracks[track_id] = detections[best_match]
                used_detections.add(best_match)
                matched_ids.add(track_id)

        # Assign new IDs to unmatched detections
        for i, det_bbox in enumerate(detections):
            if i not in used_detections:
                updated_tracks[self.next_id] = det_bbox
                self.next_id += 1

        self.tracks = updated_tracks
        return self.tracks
