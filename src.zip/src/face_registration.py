import cv2
import os
import time
from facenet_pytorch import MTCNN
import string ,random
from src.get_embedding import get_embedding

def face_detect(person_name,person_id,faces_dir,source,img_count_thresh):
    detector = MTCNN()       
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise IOError("Cannot open webcam")

    img_counter = 0
    capture_interval = 1.0  # seconds
    last_capture_time = time.time()

    print(f"Collecting face data for {person_name} (ID: {person_id})")
    print("Press 'q' to quit")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Video Streaming is ended!")
                break
            if img_counter >= img_count_thresh:
                print(f"{img_count_thresh} image is registered⚡")
                break 
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) 
            faces, probs, landmarks = detector.detect(rgb_frame, landmarks=True)
            if faces is not None:
                faces = [[max(0, cord) for cord in list(map(round, box))] for box in faces]  # list of rounded boxes
                temp = 0 
                for i,face in enumerate(faces):
                    if temp >=1:
                        continue 
                    x1,y1,x2,y2 = face 
                    # print("face cordinates : ",face)  
                    x1, y1 = max(0, x1), max(0, y1)
                    w,h = x2-x1,y2-y1 
                    # print("your face shape : ",w,h)
                    if w >75 and h > 80:
                        cv2.rectangle(frame, (x1, y1), (x2,y2), (0, 255, 0), 2)
                        # cv2.putText(frame, f"Captured: {img_counter}", (10, 30),
                                    # cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
                        
                        # To keypoints allow in registration
                        # if landmarks is not None and i < len(landmarks):
                        #     face_landmarks = [[max(0, cord) for cord in list(map(round, landmark))] for landmark in landmarks[i]]
                        #     for cord in face_landmarks:
                        #         cv2.circle(frame, tuple(cord), 2, (0, 255,0), -1)

                        current_time = time.time()
                        if current_time - last_capture_time >= capture_interval:
                            face_img = frame[y1:y2, x1:x2]
                            if face_img.size > 0 and face_img.shape[0] > 90 and face_img.shape[1] > 90:       ## Saves one face every second to avoid flooding too many images.
                                secret_code = "".join(random.choices(string.ascii_letters + string.digits,k=8))
                                img_name = os.path.join(faces_dir, f"{person_name}_{person_id}_{secret_code}_{img_counter}.png")   ## faces crop using bounding boxes as .png.
                                cv2.imwrite(img_name, face_img)
                                print(f"successfully saved image {img_counter} : ",img_name)
                                img_counter += 1
                                last_capture_time = current_time
                    temp += 1
                
                # cv2.imshow(f'Face Detection - Press Q to quit  : ', frame)
                key = cv2.waitKey(1)
                if key == ord('q'):
                    break

    finally:
        cap.release()
        # cv2.destroyAllWindows()
        print(f"✅ Collection complete. Saved {img_counter} face images to {faces_dir}")







































def face_detect_with_kafka(person_name,person_id,faces_dir,img_count_thresh,frame):
    detector = MTCNN()  
    # print("frame shape : ",frame.shape)
    if frame is not None and img_count_thresh<130:      
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB) 
        faces, probs, landmarks = detector.detect(rgb_frame, landmarks=True)   # can be None if MTCNN not found face

        # print('mtcnn performed ',faces)
        if faces is not None:
            faces = [[max(0, cord) for cord in list(map(round, box))] for box in faces]  # list of rounded boxes
            temp = 0 
            for i,face in enumerate(faces):
                if temp >=1:
                    continue 
                x1,y1,x2,y2 = face 
                # print("face cordinates : ",face)  
                x1, y1 = max(0, x1), max(0, y1)
                w,h = x2-x1,y2-y1 
                # print("face h and w : ",h,w)
                if w >75 and h > 80:
                    
                    cv2.rectangle(frame, (x1, y1), (x2,y2), (0, 255, 0), 2)

                    
                    # To keypoints allow in registration
                    # if landmarks is not None and i < len(landmarks):
                    #     face_landmarks = [[max(0, cord) for cord in list(map(round, landmark))] for landmark in landmarks[i]]
                    #     for cord in face_landmarks:
                    #         cv2.circle(frame, tuple(cord), 2, (0, 255,0), -1)

                    face_img = frame[y1:y2, x1:x2]
                    return face_img
                  
                    # secret_code = "".join(random.choices(string.ascii_letters + string.digits,k=8))
                    # img_name = os.path.join(faces_dir, f"{person_name}_{person_id}_{secret_code}.png")   
                    # print("saved your image : ",img_name)
                    # cv2.imwrite(img_name, face_img)

                temp += 1 








