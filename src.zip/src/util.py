import cv2
import torch
import numpy as np
from facenet_pytorch import InceptionResnetV1, MTCNN
from scipy.spatial.distance import cosine
from PIL import Image
import requests,random,string
import torch,cv2
import pickle
import pandas as pd 
import os
from datetime import datetime
import csv
from src.tracking_id import SimpleTracker
import warnings 


warnings.filterwarnings("ignore")
resnet = InceptionResnetV1(pretrained="vggface2").eval()  # "casia-webface"  , resnet = InceptionResnetV1().eval().to('cuda')
mtcnn = MTCNN()   #to workd on gpu > MTCNN(device='cuda')
tracker = SimpleTracker(iou_threshold=0.4)


registered_embeding_file = r"src\embedding_dir\face_embeddings.pkl"
cctv_embedding_file = r"src\embedding_dir\cctv_embeddings.pkl"
# Load saved face embeddings
with open(registered_embeding_file, "rb") as f:
    embeddings_dict = pickle.load(f)


with open(cctv_embedding_file, "rb") as f:
    cctv_embeddings_dict = pickle.load(f)






def get_embedding(face_img):
    try:
        if isinstance(face_img, np.ndarray):
            face_img = cv2.cvtColor(face_img, cv2.COLOR_BGR2RGB)
            face_img = Image.fromarray(face_img)

        aligned = mtcnn(face_img)
        if aligned is None:
            print("[INFO] MTCNN failed to align face.")
            return None
        aligned = aligned.unsqueeze(0)  
        with torch.no_grad():
            embedding = resnet(aligned)

        return embedding[0]  # Return 512-D embedding

    except Exception as e:
        print(f"[ERROR] get_embedding failed: {e}")
        return None




def match_embedding(embedding, database, threshold):
    best_match = "Unidentified"
    best_score = float("inf")
    for person, embeddings in database.items():
        for stored_embedding in embeddings:
            if len(stored_embedding)<1:
                continue

            distance = cosine(embedding.flatten(), stored_embedding.flatten())
            if distance < best_score:
                best_score = distance
                best_match = person

    if best_score < threshold:
        return (best_match, best_score)
    else:
        return ("Unidentified", best_score)


def recognize_face(face_img,match_with_registered=True, threshold=0.22):
    """
    return either
    1. person name with id 
    2. Unknown
    3. blur face 
    4. No face detected
    """

    new_embedding = get_embedding(face_img)
    
    if new_embedding is None:
        return "No face detected",0
    

    if match_with_registered:
        name, score = match_embedding(new_embedding, embeddings_dict, threshold)
        return (name, score)
    
    else:
        name, score = match_embedding(new_embedding, cctv_embeddings_dict, threshold)
        return (name, score)



## skip no faces bounding boxes detected
def isSkipFrame(detected_face_bbox_in_region):
    """
    1. if no box detected in region
    2. if box in region: check wheather all recognized as an unknown then skip
    """
    if len(detected_face_bbox_in_region)==0:
        return True 
    # elif all([True if item['NAME']=="Unknown" else False for item in detected_face_bbox_in_region ]):return True  
    else: return False

## prevent duplicate entries in attendance report
def isPresent(emp_id,file_path):
    already_logged = False
    if os.path.exists(file_path):
        with open(file_path, mode='r') as file:
            reader = csv.reader(file)
            for row in reader:
                if len(row) >= 4 and row[2] == emp_id:
                    already_logged = True
                    break
    return already_logged 


def last_login_time(filepath,emp_id):
    df = pd.read_csv(filepath)
    identified_person_data = df[df["Emp ID"] == emp_id]
    if not identified_person_data['Time'].empty:
        previous_time = identified_person_data['Time'].max()
        return previous_time

# Log known person to CSV
def log_face_info(frame,person_name,cam_id,frame_time,starting_time,second_thres=10):
    """
    function to insert the entry into sheet and send to the HRMS portal backend.
    # person_name : can be [ranjit singh_s1612, Unknown, blur face]
    """
    api_url = "http://146.88.25.149:8081/HRMS/addmodifycamerasettings/save-empcam-details"
    ## payload
    sample_data = {
    "empId": "0",
    "cameraId": "0",
    "empcamDirection": "0",
    "empcamInout": "0",
    "empcamRemark": "0",
    "empcamDt": "00/00/0000",
    "empcamTime": "00:00:00"
    }
    output_dir  = "daily report"
  
    # working on live streaming 
    if starting_time is None:
        #CODE TO BE SEND, TIMESTAMP AS PER FRAME RECIEVED IN REAL TIME
        date = frame_time.strftime("%d-%m-%Y")  
        fmt = "%H:%M:%S"
        time_str = frame_time.strftime(fmt)    


        # CODE TO BE SEND REAL TIME TIMESTAMP
        # now = datetime.now()
        # date = now.strftime("%d-%m-%Y")
        # fmt = "%H:%M:%S"
        # time_str = now.strftime(fmt)  #"10:25:23"

        direction = {0: "in", 1: "out"}


    # TO CREATE REPORT FILE
    #<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>
        os.makedirs(output_dir,exist_ok=True) 
        unique_id = "".join(random.choices(string.ascii_letters + string.digits,k=5))
        csv_file = f"{date}_attaindence_sheet.csv"
        report_file_path = os.path.join(output_dir,csv_file)

        if not os.path.exists(report_file_path):
            with open(report_file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Date", "Time", "Emp ID", "Emp Name","Cam ID"])

        csv_file = f"{date}_CCTV_report_sheet.csv"
        cctv_report_file_path = os.path.join(output_dir,csv_file)
        if not os.path.exists(cctv_report_file_path):
            with open(cctv_report_file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Date", "Time", "Emp ID", "Emp Name","Cam ID"])
    #<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>
    
        if len(person_name.split("_"))==2:  # if identified person name 
            try:
                emp_name, emp_id = person_name.split("_")
            except ValueError:
                emp_id = ""
                emp_name = person_name

            already_logged = isPresent(emp_id=emp_id,file_path=report_file_path)
            if not already_logged:
                with open(report_file_path, mode='a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow([date, time_str, emp_id, emp_name,cam_id])
                    sample_data["empId"] = emp_id
                    sample_data["cameraId"] = str(cam_id) 
                    sample_data["empcamDt"] = date 
                    sample_data["empcamTime"] = time_str 
                    sample_data['empcamDirection'] = None 
                    sample_data["empcamRemark"] = "identified" 
                    sample_data["empcamInout"] = direction.get(cam_id)
                    response = requests.post(api_url,json=sample_data)  
                    # print("Your attaindence is Marked ----->    ",[date, time_str, emp_id, emp_name,cam_id],'\n')


            # <<<<<<<<<  identified person name writing into cctv report   >>>>>>>>>>>>>>
            
            with open(cctv_report_file_path, mode='a', newline='') as file:
                writer = csv.writer(file)
                already_logged = isPresent(emp_id=emp_id,file_path=cctv_report_file_path)
                if not already_logged:
                    writer.writerow([date, time_str, emp_id, emp_name,cam_id])
                    sample_data["empId"] = emp_id
                    sample_data["cameraId"] = str(cam_id) 
                    sample_data["empcamDt"] = date 
                    sample_data["empcamTime"] = time_str 
                    sample_data['empcamDirection'] = None 
                    sample_data["empcamRemark"] = "identified" 
                    sample_data["empcamInout"] = direction.get(cam_id)
                    response = requests.post(api_url,json=sample_data)   
                    # if response.status_code == 200:print(f"Successfully sent data of ---> {sample_data['emdId']} \n")
                else:
                    # again log kro but calculate the difference 
                    prevous_time_stamp = last_login_time(filepath=cctv_report_file_path,emp_id=emp_id)
                    t1 = datetime.strptime(prevous_time_stamp,fmt)
                    t2 = datetime.strptime(time_str,fmt)
                    difference = t2 - t1 
                    diff_in_seconds = difference.total_seconds()
                    if diff_in_seconds >= second_thres:  # entry after atleast 10 second
                        writer.writerow([date, time_str, emp_id, emp_name,cam_id])
                        sample_data["empId"] = emp_id
                        sample_data["cameraId"] = str(cam_id) 
                        sample_data["empcamDt"] = date 
                        sample_data["empcamTime"] = time_str 
                        sample_data['empcamDirection'] = None 
                        sample_data["empcamRemark"] = "identified" 
                        sample_data["empcamInout"] = direction.get(cam_id)
                        # print("Name  ====>      ",emp_name,"   ====>    ",sample_data)
                        response = requests.post(api_url,json=sample_data)  
                        # if response.status_code == 200:print(f"Successfully sent data of ---> {sample_data['emdId']} \n")

    


        ## <<< writing into cctv_report_file_path  >>>>>>>>>>>>>>
        elif person_name.lower().startswith("unidentified") :
            with open(cctv_report_file_path, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([date, time_str, None,person_name,cam_id])    #unknown writing
                direction = {0: "in", 1: "out"}
                sample_data["empId"] = None 
                sample_data["cameraId"] = str(cam_id) 
                sample_data["empcamDt"] = date 
                sample_data["empcamTime"] = time_str 
                sample_data['empcamDirection'] = None 
                sample_data["empcamRemark"] = person_name  
                sample_data["empcamInout"] = direction.get(cam_id)
                # response = requests.post(api_url,json=sample_data)  

      
# Working on recorded video
    else:
        date = frame_time.strftime("%d-%m-%Y")  # fetching date from frame time
        fmt = "%H:%M:%S"
        time_str = frame_time.strftime(fmt)     # fetching time from frame time
        direction = {0: "in", 1: "out"}


        os.makedirs(output_dir,exist_ok=True) 

        csv_file = f"{date}_attaindence_sheet.csv"
        report_file_path = os.path.join(output_dir,csv_file)

        if not os.path.exists(report_file_path):
            with open(report_file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Date", "Time", "Emp ID", "Emp Name","Cam ID"])

        csv_file = f"{date}_CCTV_report_sheet.csv"
        cctv_report_file_path = os.path.join(output_dir,csv_file)
        if not os.path.exists(cctv_report_file_path):
            with open(cctv_report_file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Date", "Time", "Emp ID", "Emp Name","Cam ID"])

        if len(person_name.split("_"))==2:
            try:
                emp_name, emp_id = person_name.split("_")
            except ValueError:
                emp_id = ""
                emp_name = person_name

            already_logged = isPresent(emp_id=emp_id,file_path=report_file_path)
            if not already_logged:
                with open(report_file_path, mode='a', newline='') as file:
                    writer = csv.writer(file)
                    writer.writerow([date, time_str, emp_id, emp_name,cam_id])
                    sample_data["empId"] = emp_id
                    sample_data["cameraId"] = str(cam_id) 
                    sample_data["empcamDt"] = date 
                    sample_data["empcamTime"] = time_str 
                    sample_data['empcamDirection'] = None 
                    sample_data["empcamRemark"] = "identified" 
                    sample_data["empcamInout"] = direction.get(cam_id)
                    # response = requests.post(api_url,json=sample_data)  
                    # print("Your attaindence is Marked ----->    ",[date, time_str, emp_id, emp_name,cam_id],'\n')
                    


            # <<<<<<<<<  identified person name writing into cctv report   >>>>>>>>>>>>>>
            
            with open(cctv_report_file_path, mode='a', newline='') as file:
                writer = csv.writer(file)
                already_logged = isPresent(emp_id=emp_id,file_path=cctv_report_file_path)
                if not already_logged:
                    writer.writerow([date, time_str, emp_id, emp_name,cam_id])
                    sample_data["empId"] = emp_id
                    sample_data["cameraId"] = str(cam_id) 
                    sample_data["empcamDt"] = date 
                    sample_data["empcamTime"] = time_str 
                    sample_data['empcamDirection'] = None 
                    sample_data["empcamRemark"] = "identified" 
                    sample_data["empcamInout"] = direction.get(cam_id)
                    # response = requests.post(api_url,json=sample_data)  
                    # if response.status_code == 200:print(f"Successfully sent data of ---> {sample_data['emdId']} \n")
                else:
                    # again log kro but calculate the difference 
                    prevous_time_stamp = last_login_time(filepath=cctv_report_file_path,emp_id=emp_id)
                    t1 = datetime.strptime(prevous_time_stamp,fmt)
                    t2 = datetime.strptime(time_str,fmt)
                    difference = t2 - t1 
                    diff_in_seconds = difference.total_seconds()
                    if diff_in_seconds >= second_thres:
                        writer.writerow([date, time_str, emp_id, emp_name,cam_id])
                        sample_data["empId"] = emp_id
                        sample_data["cameraId"] = str(cam_id) 
                        sample_data["empcamDt"] = date 
                        sample_data["empcamTime"] = time_str 
                        sample_data['empcamDirection'] = None 
                        sample_data["empcamRemark"] = "identified" 
                        sample_data["empcamInout"] = direction.get(cam_id)
                        # print("Name  ====>      ",emp_name,"   ====>    ",sample_data)
                        # response = requests.post(api_url,json=sample_data) 
                        # if response.status_code == 200:print(f"Successfully sent data of ---> {sample_data['emdId']} \n")    
    


        ## <<< writing into cctv_report_file_path  >>>>>>>>>>>>>>
        elif person_name.lower().startswith("unidentified") :
            with open(cctv_report_file_path, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([date, time_str, None,person_name,cam_id])    #unknown writing
                direction = {0: "in", 1: "out"}
                sample_data["empId"] = None 
                sample_data["cameraId"] = str(cam_id) 
                sample_data["empcamDt"] = date 
                sample_data["empcamTime"] = time_str 
                sample_data['empcamDirection'] = None 
                sample_data["empcamRemark"] = person_name  
                sample_data["empcamInout"] = direction.get(cam_id)
                # print(sample_data)
                # response = requests.post(api_url,json=sample_data) 


# Utility: Get top points of bounding boxes
def find_top_point_bbox(sample_boxes):
    top_point_ls = []
    for box in sample_boxes:
        x_min, y_min, x_max, y_max = box
        points = [(x_min, y_min), (x_max, y_min)]
        top_point_ls.append(points)
    return top_point_ls

# Utility: Round bounding box coordinates
def round_values(boxes_result):
    bbox_list = []
    for box in boxes_result:
        bbox_list.append([round(value) for value in box]) # round ==> to convert float into integer (whole number)
    return bbox_list

# Main identification function
## the function detects faces in the frame
def idintifie_person(frame, red_line_x_cord, blue_line_x_cord,frame_time,starting_time):
    # print("starting time from identifie_person function  : ",starting_time)
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    boxes, _ = mtcnn.detect(rgb_frame)

    if boxes is not None:
        boxes_with_identification = []
        valid_indices = []
        boxes = round_values(boxes_result=boxes)


        tracked_objects = tracker.update( boxes)
        tracked_objects = list(tracked_objects.items())
        for idx, box in enumerate(boxes):
            output_sample = dict()
            x1, y1, x2, y2 = box 
            width = x2 - x1
            height = y2 - y1
            if width >= 65 and height >= 65:
                cv2.rectangle(frame, (x1,y1), (x2,y2), (0, 255, 0), 2)
                cv2.putText(frame, f"ID {tracked_objects[idx][0]}", (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

                TL, TR = [(x1, y1), (x2, y1)]
                top_center_x = (TL[0] + TR[0]) // 2
                top_center_y = TL[1]
                if (top_center_x < red_line_x_cord) and (top_center_x > blue_line_x_cord):   # BOX IN REGION
                    # cv2.circle(frame, (top_center_x, top_center_y), 5, (0, 0,255), -1)
                    output_sample['ID'] = tracked_objects[idx][0]
                    output_sample['BBOX'] = box
                    face_crop = frame[y1:y2, x1:x2]
                    if face_crop is None or face_crop.size == 0:
                        continue

                    similarity_thresh = 0.76  # 0.78
                    similarity_dist_threshold = round(1 - similarity_thresh  ,2)
                    person_name ,confidence_score = recognize_face(face_crop,match_with_registered=True, threshold=similarity_dist_threshold)   # best match can be (unknown or identified name)
                    confidence_score = 100 - round(confidence_score * 100,2)

                    if person_name == "No face detected":continue
                        
                    # saving the faces
                    

                    fmt = "%H-%M-%S-%f"
                    if not starting_time:
                        # print("yes starting is also None in idefied face function0---------------")

                        # now = datetime.now()
                        # time = now.strftime(fmt)
                        # dt = now.strftime("%d-%m-%Y") 

                        
                        dt = frame_time.strftime("%d-%m-%Y")  # fetching date from frame time
                        time = frame_time.strftime(fmt)     # fetching time from frame time

                      
                    else:
                        dt = frame_time.strftime("%d-%m-%Y")  # fetching date from frame time
                        time = frame_time.strftime(fmt)     # fetching time from frame time
                    

                    
                    if not person_name.lower().startswith("unidentified") :          
                        output_sample['NAME'] = person_name
                        output_sample['SIM_SCORE'] = confidence_score
                        output_sample['STATUS'] = "identified"
                        output_sample['DATE'] = dt 
                        output_sample['TIME'] = time 
                        output_sample['FACE'] = face_crop
                        boxes_with_identification.append(output_sample)
                        valid_indices.append(idx)
                    
                    elif person_name.lower().startswith("unidentified") and ((confidence_score> 38) and ((confidence_score < 54))):  # unknown in btewn 38 - 54
                        output_sample['NAME'] = person_name
                        output_sample['SIM_SCORE'] = confidence_score
                        output_sample['STATUS'] = "unidentified"
                        output_sample['DATE'] = dt 
                        output_sample['TIME'] = time 
                        output_sample['FACE'] = face_crop
                        boxes_with_identification.append(output_sample)
                        valid_indices.append(idx)


                    else: # lower and higher to the range
                        if confidence_score >= 54:  # IGNORED < 38% matched images
                            similarity_thresh = 0.79  # for cctv embedding matching threshold
                            similarity_dist_threshold = round(1 - similarity_thresh  ,2)
                            person_name ,confidence_score = recognize_face(face_crop,match_with_registered=False, threshold=similarity_dist_threshold) 
                            confidence_score = 100 - round(confidence_score * 100,2)
                            
                            if not person_name.lower().startswith('unidentified'): 
                                output_sample['NAME'] = person_name
                                output_sample['SIM_SCORE'] = confidence_score
                                output_sample['STATUS'] = "identified"
                                output_sample['DATE'] = dt 
                                output_sample['TIME'] = time 
                                output_sample['FACE'] = face_crop
                                boxes_with_identification.append(output_sample)
                                valid_indices.append(idx)
                            else: # saved into suspected folder 
                                output_sample['NAME'] = person_name
                                output_sample['SIM_SCORE'] = confidence_score
                                output_sample['STATUS'] = "unidentified"
                                output_sample['DATE'] = dt 
                                output_sample['TIME'] = time 
                                output_sample['FACE'] = face_crop
                                boxes_with_identification.append(output_sample)
                                valid_indices.append(idx)
                        else:
                            pass 

                    


                    box_height = y2 - y1
                    color = (0,  255, 0) if not person_name.lower().startswith("unidentified") else (0, 0, 255)
                    cv2.putText(frame, person_name, (x1, y1 + box_height + 20),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
        
        output = isSkipFrame(boxes_with_identification)
        return frame,  boxes_with_identification,output
    else:
        return frame, list(), True
    



















