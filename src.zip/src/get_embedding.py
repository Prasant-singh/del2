import os
import torch
import pickle
import numpy as np
import cv2
from PIL import Image
from torchvision import transforms
from facenet_pytorch import InceptionResnetV1

# === Configuration ===
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
dataset_dir = r"Data Uploaded"
embedding_dir = r"src\embedding_dir"
os.makedirs(embedding_dir, exist_ok=True)  # Ensure directory exists

# Face detector (MTCNN)




def get_embedding(dataset_dir, device, validation_embedding=False):  
    """Generate face embeddings with consistent normalization
    
    Args:
        dataset_dir: Directory containing person folders with images
        device: Torch device (cuda/cpu)
        validation_embedding: If True, returns embeddings without saving
        
    Returns:
        Dictionary of {person_name: numpy array of embeddings} if validation_embedding=True
    """
    # Load existing embeddings
    last_embedding_file_path = os.path.join(embedding_dir, "face_embeddings.pkl")
    embeddings_dictt = {}
    if os.path.exists(last_embedding_file_path):
        with open(last_embedding_file_path, "rb") as f:
            embeddings_dictt = pickle.load(f)
    registered_persons = list(embeddings_dictt.keys())
    # print("registered person : ",registered_persons)

    # Initialize model
    embedding_model = InceptionResnetV1(
        pretrained='vggface2', 
        classify=False
    ).eval().to(device)
    
    embeddings_dict = {}

    for person_folder in os.listdir(dataset_dir):
        person_path = os.path.join(dataset_dir, person_folder)
        # Skip non-folders or already registered persons
        if not os.path.isdir(person_path):
            continue
        if person_folder in registered_persons and not validation_embedding:
            continue
        person_embeddings = []
        valid_images = 0

        for img_name in os.listdir(person_path):
            if not img_name.lower().endswith(('.png', '.jpg', '.jpeg')):
                continue

            try:
                img_path = os.path.join(person_path, img_name)
                img = cv2.imread(img_path)
                face_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

                face_tensor = transforms.ToTensor()(face_img).unsqueeze(0).to(device)
                with torch.no_grad():
                    embedding = embedding_model(face_tensor)[0]
                person_embeddings.append(embedding)
                valid_images += 1

            except Exception as e:
                print(f"Error processing {img_name}: {str(e)[:200]}")
        if person_embeddings:
            # avg_embedding = np.vstack(person_embeddings).mean(axis=0)  # Use mean embedding
            embeddings_dict[person_folder] = person_embeddings
            embeddings_dictt[person_folder] = person_embeddings

            print(f"✅ {valid_images} valid faces for {person_folder}")

    if validation_embedding:
        return embeddings_dict

    # Save updated embeddings
    with open(last_embedding_file_path, "wb") as f:
        pickle.dump(embeddings_dictt, f)
    print(f"Saved embeddings for -> {person_folder} no of vector -> {len(embeddings_dictt[person_folder])} ")
    return None



# get_embedding(dataset_dir=r"\\SAGNAS\java\Jatin\Dataset\organized_images", device=device, validation_embedding=False)