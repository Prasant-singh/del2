from kafka import KafkaConsumer
import numpy as np
import os
import cv2
from datetime import datetime
import json
import base64,time 
import json
import base64
import os

# Configuration
KAFKA_TOPIC = 'hrms.employee.register.request'
KAFKA_BOOTSTRAP_SERVERS = "sdmt.saginfotech.com:9092"
GROUP_ID = "ai-reg26"




consumer = KafkaConsumer(
    KAFKA_TOPIC,
    bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
    group_id=None,  #to recieve latest one frames
    auto_offset_reset= "latest",  #"latest",  #"earliest",  
    enable_auto_commit=False
)





print("Kafka Consumer is waiting for messages...")

def is_recieving_frame():
    counter = 0
    while True:
        raw_msgs = consumer.poll(timeout_ms=500)
        if not raw_msgs:
            print("No messages yet...")
            continue

    #  value=b'{"userName":"john_doe","userPhoto":b"dfd","empCode":"303","userPhotoName":null}'
        for tp, messages in raw_msgs.items():
            for message in messages:
                try:
                    data = json.loads(message.value.decode("utf-8"))
                    name  = data.get("userName")
                    emp_code = data.get("empCode")
                    photoname = data.get("userPhotoName")
                    image_angle  = data.get("angleCode")

                    # print(name,emp_code,userphoto_name)
                    photo_base64 = data.get("userPhoto")

                    if not photo_base64:
                        print("No 'userPhoto' found in message.")
                        continue

                    # Decode Base64 → JPEG bytes
                    img_bytes = base64.b64decode(photo_base64)
                    nparr = np.frombuffer(img_bytes, np.uint8)
                    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                    if frame is None:
                        print("Failed to decode image.")
                        continue
   
                    return name,emp_code,frame,image_angle
                    # cv2.imshow("Received Frame", frame)
                    # if cv2.waitKey(1) & 0xFF == ord('q'):
                    #     cv2.destroyAllWindows()
                    #     exit()


                except Exception as e:
                    print(f"Error processing message: {e}")


