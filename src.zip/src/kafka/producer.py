from kafka import KafkaProducer
from dataclasses import dataclass
from typing import Optional
import json

KAFKA_TOPIC = "hrms.employee.register.response"
KAFKA_BOOTSTRAP_SERVERS = "sdmt.saginfotech.com:9092"
GROUP_ID = "ai-reg5"



@dataclass
class HrmsEmployeeRegisterResponse:
    userName: Optional[str] = None
    empCode: Optional[str] = None
    statusCode: Optional[str] = None  # e.g., "OK", "Created", "Already registered"
    message: Optional[str] = None
    faceAngle: Optional[str] = None
    timeStamp: Optional[str] = None

    sample_data = {
    "empId": "0",
    "cameraId": "0",
    "empcamDirection": "0",
    "empcamInout": "0",
    "empcamRemark": "0",
    "empcamDt": "00/00/0000",
    "empcamTime": "00:00:00"
    }

@dataclass
class DetectedBoxResult:
    empId: Optional[str] = None
    cameraId: Optional[str] = None
    empcamDirection: Optional[str] = None  # e.g., "OK", "Created", "Already registered"
    empcamRemark: Optional[str] = None
    empcamDt: Optional[str] = None
    empcamTime: Optional[str] = None

def response_writer(message):
    producer = KafkaProducer(
    bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS)
    future = producer.send(KAFKA_TOPIC, value=message)

    try:
        record_metadata = future.get(timeout=1)  # waits until sent for acknoldgment
        print(f"✅Sent to topic={record_metadata.topic}, "
                f"partition={record_metadata.partition}, "
                f"offset={record_metadata.offset}")
    except Exception as e:
        print(f"Failed to send message: {e}")


    print(f"message sent : {message}")

# # Wait until all messages are sent
    producer.flush()
    producer.close()


# response_writer()
# ✅Sent to topic=hrms.employee.register.response, partition=0, offset=121515
